public class PingException extends PingPongException {
}
