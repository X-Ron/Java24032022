public class PingPongException extends Exception {
}
