public class PongException extends PingPongException {
}
